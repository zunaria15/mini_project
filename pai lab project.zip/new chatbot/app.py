

# from flask import Flask, request, jsonify, render_template
# from langchain_core.prompts import ChatPromptTemplate
# from langchain_core.output_parsers import StrOutputParser
# from langchain_groq import ChatGroq
# from dotenv import load_dotenv
# import os
# import requests  # ✅ Make sure this is imported before usage

# # Load environment variables
# load_dotenv()

# # Get Groq API key
# groq_api_key = os.getenv("GROQ_API_KEY")

# # Initialize Flask app
# app = Flask(__name__)

# # Initialize LLM (Langchain-Groq)
# llm = ChatGroq(
#     groq_api_key=groq_api_key,
#     model_name="llama3-8b-8192",
#     temperature=0.7
# )

# # Prompt template
# template = """
# You are a helpful e-commerce chatbot. Answer the user's question clearly and concisely.
# Product Information:
# {product_info}

# User Question:
# {question}
# """

# prompt = ChatPromptTemplate.from_template(template)
# output_parser = StrOutputParser()

# # Static product info
# product_info = """
# Welcome to our online store! We sell:
# - Electronics (mobiles, laptops, accessories)
# - Fashion (men, women, kids)
# - Home & Kitchen (cookware, cleaning, decor)
# Enjoy free shipping over $50 and a 7-day return policy!
# """

# # Home route
# @app.route('/')
# def home():
#     return render_template('index.html')

# # Chat route
# @app.route('/chat', methods=['POST'])
# def chat():
#     try:
#         data = request.get_json()
#         question = data.get('question', '')

#         if not question:
#             return jsonify({"error": "No question provided"}), 400

#         # Format the prompt
#         formatted_prompt = prompt.format(product_info=product_info, question=question)

#         # Get raw response from Groq API
#         raw_response = llm.invoke(formatted_prompt)
#         print("Raw Groq Response:", raw_response)

#         # Parse the response
#         answer = output_parser.invoke(raw_response)
#         print("Parsed Answer:", answer)

#         return jsonify({"answer": answer})

#     except Exception as e:
#         print("Error:", str(e))
#         return jsonify({"error": "Chatbot is currently unavailable."}), 500

# if __name__ == '__main__':
#     app.run(debug=True)







# from flask import Flask, request, jsonify, render_template
# from langchain_core.prompts import ChatPromptTemplate
# from langchain_core.output_parsers import StrOutputParser
# from langchain_groq import ChatGroq
# from dotenv import load_dotenv
# import os

# # Load environment variables from .env file
# load_dotenv()

# # Get Groq API key from environment
# groq_api_key = os.getenv("GROQ_API_KEY")

# # Initialize Flask app
# app = Flask(__name__)

# # Initialize Groq LLM
# llm = ChatGroq(
#     groq_api_key=groq_api_key,
#     model_name="llama3-8b-8192",
#     temperature=0.7
# )

# # Define prompt template
# template = """
# You are a helpful e-commerce chatbot. Answer the user's question clearly and concisely.
# If the product is mentioned in the catalog, also return a related image URL.

# Product Catalog:
# - Electronics:
#   - Mobiles: Latest smartphones.
#     - Image: https://via.placeholder.com/200x150?text=Mobiles
#   - Laptops: Powerful laptops for work and gaming.
#     - Image: https://via.placeholder.com/200x150?text=Laptops
#   - Accessories: Chargers, cases, headphones.
#     - Image: https://via.placeholder.com/200x150?text=Accessories

# - Fashion:
#   - Men, Women, Kids apparel and shoes.
#     - Image: https://via.placeholder.com/200x150?text=Fashion

# - Home & Kitchen:
#   - Cookware, decor, cleaning items.
#     - Image: https://via.placeholder.com/200x150?text=Home+%26+Kitchen

# - Return Policy: 7-day returns.
# - Free shipping over $50.

# User Question:
# {question}
# """

# prompt = ChatPromptTemplate.from_template(template)
# output_parser = StrOutputParser()

# # Home route
# @app.route('/')
# def home():
#     return render_template('index.html')

# # Chat API route
# @app.route('/chat', methods=['POST'])
# def chat():
#     try:
#         data = request.get_json()
#         question = data.get('question', '')

#         if not question:
#             return jsonify({"error": "No question provided"}), 400

#         # Create prompt with user's question
#         formatted_prompt = prompt.format(question=question)

#         # Invoke LLM with prompt
#         raw_response = llm.invoke(formatted_prompt)
#         print("Raw Groq Response:", raw_response)

#         # Extract clean response
#         answer = output_parser.invoke(raw_response)
#         print("Parsed Answer:", answer)

#         return jsonify({"answer": answer})

#     except Exception as e:
#         print("Error:", str(e))
#         return jsonify({"error": "Chatbot is currently unavailable."}), 500

# # Run app
# if __name__ == '__main__':
#     app.run(debug=True)










# from flask import Flask, request, jsonify, render_template
# from langchain_core.prompts import ChatPromptTemplate
# from langchain_core.output_parsers import StrOutputParser
# from langchain_groq import ChatGroq
# from dotenv import load_dotenv
# import os

# # Load API key from .env
# load_dotenv()
# groq_api_key = os.getenv("GROQ_API_KEY")

# # Flask app setup
# app = Flask(__name__)

# # Initialize Groq LLM
# llm = ChatGroq(
#     groq_api_key=groq_api_key,
#     model_name="llama3-8b-8192",
#     temperature=0.7
# )

# # Prompt template
# template = """
# You are a helpful e-commerce chatbot. Provide clear answers. If a product is mentioned, describe it and give a suitable image URL.

# Product Catalog:
# - Mobiles: Latest smartphones.
# - Laptops: Powerful laptops for work and gaming.
# - Accessories: Chargers, headphones, cases.
# - Fashion: Men, women, and kids clothing and shoes.
# - Cookware: Non-stick pans, pots.
# - Decor: Home decoration items.
# - Cleaning: Home cleaning tools.

# Free shipping over $50. 7-day return policy.

# User Question:
# {question}
# """

# # LangChain setup
# prompt = ChatPromptTemplate.from_template(template)
# output_parser = StrOutputParser()

# # Map keywords to image URLs
# product_images = {
#     "mobiles": "https://via.placeholder.com/200x150?text=Mobiles",
#     "laptops": "https://via.placeholder.com/200x150?text=Laptops",
#     "accessories": "https://via.placeholder.com/200x150?text=Accessories",
#     "fashion": "https://via.placeholder.com/200x150?text=Fashion",
#     "cookware": "https://via.placeholder.com/200x150?text=Cookware",
#     "decor": "https://via.placeholder.com/200x150?text=Home+Decor",
#     "cleaning": "https://via.placeholder.com/200x150?text=Cleaning"
# }

# # Routes
# @app.route('/')
# def home():
#     return render_template('index.html')

# @app.route('/chat', methods=['POST'])
# def chat():
#     try:
#         data = request.get_json()
#         question = data.get('question', '')

#         if not question:
#             return jsonify({"error": "No question provided"}), 400

#         # Format and query the model
#         formatted_prompt = prompt.format(question=question)
#         raw_response = llm.invoke(formatted_prompt)
#         answer = output_parser.invoke(raw_response)

#         # Detect keyword for image
#         image_url = ""
#         for keyword, url in product_images.items():
#             if keyword.lower() in answer.lower():
#                 image_url = url
#                 break

#         return jsonify({"answer": answer, "image": image_url})

#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# if __name__ == '__main__':
#     app.run(debug=True)












from flask import Flask, request, jsonify, render_template
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_groq import ChatGroq
from dotenv import load_dotenv
import os
# Load environment variables
load_dotenv()
groq_api_key = os.getenv("GROQ_API_KEY")
app = Flask(__name__)
# Initialize LLM
llm = ChatGroq(
    groq_api_key=groq_api_key,
    model_name="llama3-8b-8192",
    temperature=0.7
)
# Prompt template
template = """
You are a helpful e-commerce chatbot. Provide clear answers. If a product is mentioned, describe it and give a suitable image URL.
Product Catalog:
- Mobiles: Latest smartphones.
- Laptops: Powerful laptops for work and gaming.
- Accessories: Chargers, headphones, cases.
- Fashion: Men, women, and kids clothing and shoes.
- Cookware: Non-stick pans, pots.
- Decor: Home decoration items.
- Cleaning: Home cleaning tools.

Free shipping over $50. 7-day return policy.

User Question:
{question}
"""
prompt = ChatPromptTemplate.from_template(template)
output_parser = StrOutputParser()

product_images = {
    "mobiles": "https://via.placeholder.com/200x150?text=Mobiles",
    "laptops": "https://via.placeholder.com/200x150?text=Laptops",
    "accessories": "https://via.placeholder.com/200x150?text=Accessories",
    "fashion": "https://via.placeholder.com/200x150?text=Fashion",
    "cookware": "https://via.placeholder.com/200x150?text=Cookware",
    "decor": "https://via.placeholder.com/200x150?text=Decor",
    "cleaning": "https://via.placeholder.com/200x150?text=Cleaning"
}

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        question = data.get('question', '')

        if not question:
            return jsonify({"error": "No question provided"}), 400

        formatted_prompt = prompt.format(question=question)
        raw_response = llm.invoke(formatted_prompt)
        answer = output_parser.invoke(raw_response)

        image_url = ""
        for keyword, url in product_images.items():
            if keyword.lower() in answer.lower():
                image_url = url
                break

        return jsonify({"answer": answer, "image": image_url})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)

