function sendMessage() {
    const inputField = document.getElementById("user-input");
    const chatBox = document.getElementById("chat-box");
    const typingIndicator = document.getElementById("typing");

    let userMessage = inputField.value.trim();
    if (userMessage === "") return;

    // Show user's message
    chatBox.innerHTML += `<div class="message user-message">${userMessage}</div>`;
    inputField.value = "";
    chatBox.scrollTop = chatBox.scrollHeight;

    // Show typing indicator
    typingIndicator.style.display = "block";

    // Send request to Flask backend
    fetch('/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ question: userMessage })
    })
    .then(response => response.json())
    .then(data => {
        typingIndicator.style.display = "none";

        // Show bot's text response
        chatBox.innerHTML += `<div class="message bot-message">${data.answer}</div>`;

        // Show image if included
        if (data.image) {
            chatBox.innerHTML += `
                <div class="message bot-message">
                    <img src="${data.image}" alt="Product Image" class="product-image">
                </div>`;
        }

        chatBox.scrollTop = chatBox.scrollHeight;
    })
    .catch(error => {
        typingIndicator.style.display = "none";
        chatBox.innerHTML += `<div class="message bot-message error">❌ Something went wrong.</div>`;
        console.error("Error:", error);
    });
}
